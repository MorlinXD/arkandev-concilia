// Simula al Email Worker: envía un .eml a la app local.
// Uso: npm run email:send -- tests/fixtures/pichincha.eml [alias] [codigo]
//   codigo (opcional): reemplaza el código de venta del correo, ej. V-8594. Así no hay que editar el .eml.
import { readFileSync } from "node:fs";
import "dotenv/config";

const [file, aliasArg, codeArg] = process.argv.slice(2);
if (!file) { console.error("Uso: npm run email:send -- <archivo.eml> [alias]"); process.exit(1); }
const alias = aliasArg ?? process.env.DEV_ALIAS;
if (!alias) { console.error("Indica el alias (lo ves en el panel) o define DEV_ALIAS en .env"); process.exit(1); }

const domain = process.env.NEXT_PUBLIC_INBOUND_DOMAIN ?? "in.arkandevstudio.com";
const res = await fetch((process.env.APP_URL ?? "http://localhost:3000") + "/api/inbound", {
  method: "POST",
  headers: { "content-type": "message/rfc822", "x-ingest-secret": process.env.INGEST_SECRET, "x-inbound-to": `${alias}@${domain}` },
  // Message-ID único en cada envío para poder repetir la prueba
  body: (() => {
    let eml = readFileSync(file, "utf8").replace(/^Message-ID:.*$/im, `Message-ID: <${Date.now()}@test>`);
    if (codeArg) {
      const code = codeArg.toUpperCase();
      if (!/^V-\d{4}$/.test(code)) { console.error("El código debe tener la forma V-1234"); process.exit(1); }
      eml = eml.replace(/V[\s\-_.]?\d{4}(?!\d)/g, code);
    }
    return eml;
  })(),
});
console.log(res.status, JSON.stringify(await res.json(), null, 2));

import { bankFromAddress, type Bank } from "./banks";
import { direction, findAmount, findLabeled, findSaleCodes, htmlToText } from "./extract";

export type EmailInput = {
  from: string;                       // dirección del remitente original
  subject: string;
  text?: string | null;
  html?: string | null;
  headers: { key: string; value: string }[];
  /** Destinatarios originales (To, Delivered-To, X-Forwarded-For…), para saber por qué buzón del negocio pasó. */
  recipients?: string[];
};

export type ParsedTransfer = {
  ok: true;
  bank: string;
  bankId: string | null;
  amount: number;
  memo: string;                       // concepto + códigos encontrados en todo el correo
  sender: string | null;
  reference: string | null;
  direction: "credit" | "unknown";
  dkim: boolean;
  /** true solo si: banco conocido + firma DKIM válida + dinero entrante. Si es false, nunca se aprueba solo. */
  trusted: boolean;
  warnings: string[];
};

export type ParseFailure = { ok: false; reason: "outgoing" | "no_amount" | "not_bank"; detail?: string };

/** Servidores cuya cabecera Authentication-Results consideramos confiable (la agrega el receptor, no el remitente). */
const TRUSTED_AUTHSERV = /(cloudflare|mx\.google\.com|google\.com|outlook\.com|protection\.outlook\.com|yahoo\.com|zoho)/i;

/** ¿Algún receptor confiable validó la firma DKIM con el dominio del banco? */
export function dkimPassFor(headers: EmailInput["headers"], bank: Bank | null): boolean {
  if (!bank) return false;
  const results = headers
    .filter((h) => /^(arc-)?authentication-results$/i.test(h.key))
    .map((h) => h.value.replace(/^\s*i=\d+;\s*/i, ""));
  return results.some((value) => {
    const authserv = value.split(";")[0]?.trim() ?? "";
    if (!TRUSTED_AUTHSERV.test(authserv)) return false;
    for (const m of value.matchAll(/dkim=pass[^;]*?header\.(?:d=|i=@?)([a-z0-9.\-]+)/gi)) {
      const d = m[1].toLowerCase();
      if (bank.domains.some((bd) => d === bd || d.endsWith("." + bd))) return true;
    }
    return false;
  });
}

export type ParseOptions = {
  /** Bancos configurados por el negocio (sección "Bancos" del panel). */
  tenantBanks?: Bank[];
};

export function parseBankEmail(email: EmailInput, opts: ParseOptions = {}): ParsedTransfer | ParseFailure {
  const tenantBanks = opts.tenantBanks ?? [];
  const bank = bankFromAddress(email.from, tenantBanks);
  // Si el negocio registró bancos, un correo de otro banco no es confiable (¿cuenta ajena? ¿suplantación?)
  const registered = tenantBanks.length === 0 || (!!bank && tenantBanks.some((b) => b.id === bank.id));
  const body = email.text?.trim() ? email.text : htmlToText(email.html ?? "");
  const full = `${email.subject}\n${body}`;
  const lines = full.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const warnings: string[] = [];

  const dir = direction(full);
  if (dir === "debit") return { ok: false, reason: "outgoing", detail: "El correo describe dinero que SALE de la cuenta" };

  const amount = findAmount(lines, full);
  if (!amount) return { ok: false, reason: "no_amount", detail: "No se encontró un monto" };

  const memoLabel = findLabeled(lines, "memo");
  const codes = findSaleCodes(full);
  const memo = [memoLabel, ...codes.filter((c) => !memoLabel?.toUpperCase().includes(c))].filter(Boolean).join(" · ");

  const dkim = dkimPassFor(email.headers, bank);
  if (!bank) warnings.push("Remitente no reconocido como banco");
  if (bank && !dkim) warnings.push("No se pudo verificar la firma DKIM del banco");
  if (dir === "unknown") warnings.push("No se pudo confirmar que sea dinero entrante");
  if (bank && !registered) warnings.push(`${bank.name} no está registrado en tus bancos`);

  // ¿Llegó por el correo del negocio registrado para este banco?
  const expected = tenantBanks.find((b) => b.id === bank?.id)?.mailboxes ?? [];
  const recipients = (email.recipients ?? []).map((r) => r.toLowerCase());
  const mailboxOk = expected.length === 0 || expected.some((m) => recipients.includes(m));
  if (!mailboxOk) warnings.push(`Llegó a un correo distinto al registrado (${expected.join(", ")})`);

  return {
    ok: true,
    bank: bank?.name ?? `Desconocido (${email.from.split("@")[1] ?? "?"})`,
    bankId: bank?.id ?? null,
    amount,
    memo,
    sender: findLabeled(lines, "sender"),
    reference: findLabeled(lines, "reference"),
    direction: dir,
    dkim,
    trusted: !!bank && dkim && dir === "credit" && registered && mailboxOk,
    warnings,
  };
}

/** Correo de confirmación de reenvío de Gmail/Outlook: hay que mostrarle el enlace al negocio. */
export function forwardingConfirmation(email: EmailInput): string | null {
  const from = email.from.toLowerCase();
  const isGmail = from.includes("forwarding-noreply@google.com");
  const isOutlook = /outlook|microsoft/.test(from) && /reenv|forward/i.test(email.subject);
  if (!isGmail && !isOutlook) return null;
  const body = email.text ?? htmlToText(email.html ?? "");
  const link = /(https:\/\/(?:mail(?:-settings)?\.google\.com|[a-z0-9.-]*(?:outlook|live|microsoft)\.com)\/[^\s<>"')]+)/i.exec(body)?.[1];
  const code = /(?:c[oó]digo de confirmaci[oó]n|confirmation code)[^\d]*(\d{6,12})/i.exec(body)?.[1];
  return [link, code ? `Código: ${code}` : null].filter(Boolean).join(" · ") || email.subject;
}

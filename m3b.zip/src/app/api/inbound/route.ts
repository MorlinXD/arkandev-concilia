import { json } from "@/lib/context";
import { hasIngestSecret } from "@/lib/secret";
import { processInboundEmail } from "@/lib/inbound";

/**
 * Recibe el correo CRUDO (MIME) que envía el Email Worker de Cloudflare.
 * Cabeceras: x-ingest-secret, x-inbound-to (dirección destino <alias>@dominio).
 */
export async function POST(req: Request) {
  if (!hasIngestSecret(req)) return json({ error: "unauthorized" }, 401);
  const to = req.headers.get("x-inbound-to");
  if (!to) return json({ error: "missing x-inbound-to" }, 400);
  const raw = await req.text();
  if (!raw || raw.length > 5_000_000) return json({ error: "invalid body" }, 400);
  const outcome = await processInboundEmail(raw, to);
  return json(outcome);
}

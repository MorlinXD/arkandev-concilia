import { desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { getContext, json } from "@/lib/context";

/** Lo que el panel consulta cada pocos segundos. */
export async function GET() {
  const ctx = await getContext();
  if (!ctx?.tenant) return json({ error: "No autorizado" }, 401);
  const tenantId = ctx.tenant.id;

  const [sales, transfers, emails] = await Promise.all([
    db.select().from(schema.sales).where(eq(schema.sales.tenantId, tenantId)).orderBy(desc(schema.sales.createdAt)).limit(50),
    db.select().from(schema.transfers).where(eq(schema.transfers.tenantId, tenantId)).orderBy(desc(schema.transfers.receivedAt)).limit(50),
    db.select().from(schema.inboundEmails).where(eq(schema.inboundEmails.tenantId, tenantId)).orderBy(desc(schema.inboundEmails.createdAt)).limit(15),
  ]);
  return json({ sales, transfers, emails, forwardingConfirmation: ctx.tenant.forwardingConfirmation });
}

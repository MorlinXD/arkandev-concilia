import PostalMime from "postal-mime";
import { createHash } from "node:crypto";
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { forwardingConfirmation, parseBankEmail, type EmailInput } from "@/parsers";
import { bankFromAddress, banksFromAccounts, type Bank } from "@/parsers/banks";
import { ingestTransfer, type ReconcileResult } from "./reconcile";

export type InboundOutcome =
  | { status: "processed"; parse: ReturnType<typeof parseBankEmail>; result: ReconcileResult }
  | { status: "forwarding_confirmation"; info: string }
  | { status: "ignored" | "failed"; detail: string };

/** Si el correo fue reenviado a mano ("Fwd:"), busca el remitente original dentro del cuerpo. */
function originalSenderInBody(text: string, tenantBanks: Bank[]): string | null {
  for (const m of text.matchAll(/^(?:>?\s*)(?:De|From)\s*:\s*.*?<?([a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,})>?/gim)) {
    if (bankFromAddress(m[1], tenantBanks)) return m[1];
  }
  return null;
}

/** Procesa un correo crudo (MIME) recibido en <alias>@dominio. */
export async function processInboundEmail(raw: string, recipient: string): Promise<InboundOutcome> {
  const alias = recipient.toLowerCase().split("@")[0].split("+")[0];
  const [tenant] = await db.select().from(schema.tenants).where(eq(schema.tenants.inboundAlias, alias)).limit(1);

  const mail = await PostalMime.parse(raw);
  let from = mail.from?.address ?? "";
  const email: EmailInput = {
    from,
    subject: mail.subject ?? "",
    text: mail.text ?? null,
    html: mail.html ?? null,
    headers: (mail.headers ?? []).map((h) => ({ key: h.key, value: h.value })),
  };

  const log = (status: "processed" | "ignored" | "failed" | "forwarding_confirmation", detail: string | null, transferId?: string) =>
    db.insert(schema.inboundEmails).values({
      tenantId: tenant?.id ?? null, recipient: recipient.slice(0, 255), fromAddress: from.slice(0, 255) || null,
      subject: email.subject.slice(0, 255) || null, status, detail: detail?.slice(0, 500) ?? null, transferId: transferId ?? null,
    });

  if (!tenant) {
    await log("ignored", `Alias desconocido: ${alias}`);
    return { status: "ignored", detail: "unknown_tenant" };
  }

  const confirmation = forwardingConfirmation(email);
  if (confirmation) {
    await db.update(schema.tenants).set({ forwardingConfirmation: confirmation.slice(0, 600) }).where(eq(schema.tenants.id, tenant.id));
    await log("forwarding_confirmation", confirmation);
    return { status: "forwarding_confirmation", info: confirmation };
  }

  const accounts = await db.select().from(schema.bankAccounts).where(eq(schema.bankAccounts.tenantId, tenant.id));
  const tenantBanks = banksFromAccounts(accounts);

  // Reenvío manual: el remitente es el propio negocio; buscamos el banco original en el cuerpo.
  if (!bankFromAddress(from, tenantBanks)) {
    const original = originalSenderInBody(email.text ?? "", tenantBanks);
    if (original) { from = original; email.from = original; email.headers = []; }
  }

  const parse = parseBankEmail(email, { tenantBanks });
  if (!parse.ok) {
    await log("ignored", `${parse.reason}${parse.detail ? `: ${parse.detail}` : ""}`);
    return { status: "ignored", detail: parse.reason };
  }

  const rawHash = createHash("sha256").update(mail.messageId || raw).digest("hex");
  try {
    const result = await ingestTransfer({
      alias, bank: parse.bank, amount: parse.amount, memo: parse.memo || null,
      sender: parse.sender, reference: parse.reference,
      receivedAt: mail.date ? new Date(mail.date) : undefined,
      rawHash, trusted: parse.trusted,
    });
    const detail = [result.result, ...parse.warnings].join(" · ");
    await log("processed", detail, "transferId" in result ? result.transferId : undefined);
    return { status: "processed", parse, result };
  } catch (e) {
    await log("failed", e instanceof Error ? e.message : String(e));
    return { status: "failed", detail: "error" };
  }
}

# Despliegue de Concilia · by Arkandev

Arquitectura de producción (costo cero):

```
Banco ─▶ correo del negocio ─(filtro de reenvío)─▶ pagos+<alias>@in.arkandevstudio.com
                                                         │  Cloudflare Email Routing (gratis)
                                                         ▼
                                              Email Worker "concilia-email-worker"
                                                         │  POST /api/inbound (con INGEST_SECRET)
                                                         ▼
                         Hostinger: concilia.arkandevstudio.com (Next.js) ──▶ MySQL de Hostinger
```

> **¿Por qué `pagos+<alias>@`?** Cloudflare solo permite reglas *catch-all* en el dominio raíz. En el subdominio
> usamos una sola dirección, `pagos@in.arkandevstudio.com`, con **subdirecciones** (`+alias`) para identificar a cada negocio.

**Tiempo estimado:** 1–2 horas, más la propagación de DNS (de minutos a 24 h).

---

## 0. Antes de empezar

- [ ] Acceso al **registrador** de `arkandevstudio.com` (donde se compró el dominio) para cambiar los *nameservers*.
- [ ] Acceso a **Hostinger** (plan Business) donde vivirá la app. Idealmente una cuenta **a tu nombre**.
- [ ] Una cuenta gratuita en **Cloudflare** (dash.cloudflare.com).
- [ ] Node.js instalado en tu PC (ya lo tienes) para desplegar el Worker.

> ⚠️ **El paso 2 mueve TODO el DNS de `arkandevstudio.com` a Cloudflare.** Si el dominio tiene sitio web o correo
> (p. ej. `jean.morales@arkandevstudio.com`), hay que copiar sus registros exactamente o dejarán de funcionar.
> Por eso el paso 1 es hacer un inventario.

---

## 1. Inventario del DNS actual

En el panel donde hoy se administra el DNS (Hostinger: **Dominios → arkandevstudio.com → DNS / Nameservers**),
toma una captura o anota **todos** los registros. Los más importantes:

| Tipo | Para qué sirve | Ejemplo típico de Hostinger |
|---|---|---|
| `A` / `CNAME` de `@` y `www` | El sitio web | IP del servidor de Hostinger |
| `MX` | Recibir el correo del dominio | `mx1.hostinger.com`, `mx2.hostinger.com` |
| `TXT` con `v=spf1` | Que tus correos no caigan en spam | `v=spf1 include:_spf.mail.hostinger.com ~all` |
| `CNAME`/`TXT` de DKIM y `_dmarc` | Autenticación del correo | `hostingermail-a._domainkey` … |

## 2. Pasar el dominio a Cloudflare (DNS gratis)

1. Cloudflare → **Add a domain** → `arkandevstudio.com` → plan **Free**.
2. Cloudflare importa los registros. **Compáralos uno por uno con tu inventario** y agrega los que falten.
3. Pon los registros del sitio y del correo en **DNS only** (nube gris) para no alterar nada al inicio.
4. Cloudflare te dará **dos nameservers** (p. ej. `ana.ns.cloudflare.com`, `bob.ns.cloudflare.com`).
5. En el registrador del dominio (Hostinger: **Dominios → arkandevstudio.com → Nameservers → Cambiar nameservers**),
   reemplaza los actuales por los de Cloudflare.
6. Espera a que Cloudflare marque el dominio como **Active** (te llega un correo).
7. ✅ Verifica que `https://arkandevstudio.com` sigue cargando y que **recibes correos** en las cuentas del dominio.

## 3. Base de datos en Hostinger

hPanel → **Bases de datos → Gestión → Crear nueva base de datos MySQL**:

- Nombre: `concilia` (Hostinger antepone un prefijo, p. ej. `u123456789_concilia`).
- Usuario: `concilia` (máximo 14 caracteres; **no** uses un correo).
- Contraseña fuerte. Anota los tres datos y el **host** que muestra hPanel (normalmente `localhost`).

## 4. Publicar la app en Hostinger

1. Completa `.env.production.example` y guárdalo como `.env.production` (no lo subas a GitHub):
   - `DATABASE_URL=mysql://USUARIO:CONTRASEÑA@HOST:3306/BASE`
   - `BETTER_AUTH_SECRET`: genera uno nuevo →
     `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`
   - `INGEST_SECRET`: genera otro igual. **Guárdalo**: lo usarás en el Worker.
   - `BETTER_AUTH_URL=https://concilia.arkandevstudio.com`
2. hPanel → **Websites → Add website → Node.js web app**.
3. Origen del código, una de dos:
   - **Subir .zip:** sube `arkandev-concilia-hostinger.zip` (sin `node_modules`, `.next` ni `.env`).
   - **GitHub** (recomendado a futuro): sube el proyecto a un repositorio privado y conéctalo; cada `git push` redepliega.
4. Dominio: elige **subdominio** `concilia.arkandevstudio.com`.
5. Configuración de compilación (Hostinger detecta Next.js):
   - Versión de Node: **20 o 22**
   - Build: `npm run build`
   - Start: `npm start`  ← aplica las migraciones de la base de datos automáticamente al arrancar
6. **Environment variables → Import from .env file** → elige tu `.env.production` → revisa → **Confirm**.
7. **Deploy**.
8. Si Hostinger indica un registro DNS para el subdominio (A o CNAME), créalo en **Cloudflare → DNS** como
   `concilia` → *DNS only* (nube gris).
9. ✅ Abre `https://concilia.arkandevstudio.com/login`, crea tu cuenta y tu negocio.
   En **Bancos** debes ver tu dirección `pagos+xxxxxxxxxx@in.arkandevstudio.com`.

> Los registros de la app (errores, migraciones) se ven en hPanel → tu Web App → **Logs**.

## 5. Recepción de correos en Cloudflare

1. Cloudflare → `arkandevstudio.com` → **Email → Email Routing**.
   - Si te pide "habilitar" Email Routing y **agregar registros MX al dominio raíz**, **no lo hagas** si tu correo
     del dominio está en Hostinger: reemplazaría tus MX y dejarías de recibir correo en `@arkandevstudio.com`.
     Solo necesitamos el **subdominio**.
2. **Settings → Subdomains** → agrega `in` (queda `in.arkandevstudio.com`). Cloudflare crea los MX y SPF **del subdominio**.
3. **Settings → Subaddressing** → **Enable** (activa el soporte de `pagos+alias@`).

## 6. Desplegar el Email Worker (desde tu PC)

```cmd
cd C:\Users\Usuario\Desktop\arkandev-concilia\worker
npm install
npx wrangler login
npx wrangler secret put INGEST_SECRET
npm run deploy
```
- `wrangler login` abre el navegador para autorizar tu cuenta de Cloudflare.
- En `secret put`, pega **el mismo** `INGEST_SECRET` que pusiste en Hostinger.
- Revisa que `wrangler.toml` tenga `APP_URL = "https://concilia.arkandevstudio.com"`.

## 7. Regla de enrutamiento

Cloudflare → **Email Routing → Routing rules → Create address**:

- Custom address: `pagos` @ `in.arkandevstudio.com`
- Action: **Send to a Worker** → `concilia-email-worker`
- **Save**

## 8. Prueba de punta a punta

1. Desde cualquier correo, envía un mensaje cualquiera a tu dirección `pagos+TUALIAS@in.arkandevstudio.com`.
2. En el **Panel → Correos recibidos** debe aparecer en segundos (como *Ignorado · No contiene un monto*: es lo correcto,
   demuestra que la cadena Cloudflare → Worker → Hostinger funciona).
3. Sigue el **tutorial de Bancos** (botón *Ver tutorial*) para autorizar el reenvío en Gmail: el código de confirmación
   aparecerá en la tarjeta *Correo de reenvío* del Panel.
4. Crea el filtro, haz una transferencia de prueba de $1 con el código en el concepto y mira cómo se aprueba sola. 🎉

---

## Solución de problemas

| Síntoma | Causa probable | Qué hacer |
|---|---|---|
| El correo de prueba no aparece en "Correos recibidos" | Falta la regla `pagos@`, el subaddressing o el subdominio | Revisa los pasos 5 y 7. En Cloudflare → Email Routing → **Activity log** verás si llegó y qué hizo |
| Aparece en el Activity log como *Worker error* | La app no responde o el secreto no coincide | `cd worker && npx wrangler tail` muestra el error en vivo; revisa `APP_URL` e `INGEST_SECRET` |
| Error 401 en los logs de Hostinger para `/api/inbound` | `INGEST_SECRET` distinto en Worker y Hostinger | Vuelve a ejecutar `npx wrangler secret put INGEST_SECRET` con el valor correcto |
| "Invalid origin" al iniciar sesión | `BETTER_AUTH_URL` no coincide con la URL real | Debe ser exactamente `https://concilia.arkandevstudio.com` |
| Error de conexión a la base de datos | `DATABASE_URL` mal escrita | Revisa usuario, contraseña (caracteres especiales codificados), host y nombre con prefijo |
| Dejó de llegar el correo de `@arkandevstudio.com` | Se perdieron los MX del dominio raíz | Vuelve a crear en Cloudflare los registros MX/SPF/DKIM de tu inventario (paso 1) |
